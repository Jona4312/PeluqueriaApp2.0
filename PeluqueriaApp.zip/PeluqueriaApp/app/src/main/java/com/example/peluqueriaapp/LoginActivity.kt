package com.example.peluqueriaapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.peluqueriaapp.database.AppDatabase
import com.example.peluqueriaapp.databinding.ActivityLoginBinding
import com.example.peluqueriaapp.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Navegar a RegisterActivity
        binding.tvRegister.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }

        // Manejar el botón de inicio de sesión
        binding.btnLoginUser.setOnClickListener {
            val email = binding.etUsernameLogin.text.toString().trim()
            val password = binding.etPasswordLogin.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                // Mostrar un mensaje solo cuando ambos campos estén vacíos
                Toast.makeText(this, "Por favor ingrese los datos correctamente", Toast.LENGTH_SHORT).show()
            } else {
                // Llamar a la función que verifica las credenciales
                checkCredentials(email, password)
            }
        }
    }

    private fun checkCredentials(email: String, password: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val db = AppDatabase.getDatabase(applicationContext)
            val user = db.userDao().getUser(email, password)

            withContext(Dispatchers.Main) {
                if (user != null) {
                    // Usuario encontrado, redirigir a MainActivity
                    val intent = Intent(this@LoginActivity, MainActivity::class.java)
                    startActivity(intent)
                    finish() // Cerrar LoginActivity para evitar regresar
                } else {
                    // Usuario no encontrado o credenciales incorrectas
                    Toast.makeText(this@LoginActivity, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
