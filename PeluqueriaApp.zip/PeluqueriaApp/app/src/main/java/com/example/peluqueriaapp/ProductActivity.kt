package com.example.peluqueriaapp.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.peluqueriaapp.adapters.ProductAdapter
import com.example.peluqueriaapp.databinding.ActivityProductBinding

class ProductActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProductBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Lista de productos con nombre y precio como pares
        val products = listOf(
            "Shampoo" to 4.990,
            "Acondicionador" to 3.990,
            "Cera para el cabello" to 6.000,
            "Gel" to 2.490,
            "Tijeras profesionales" to 12.990 ,
            "corte caballero:" to 15.000,
            "corte niño" to 15.000,
            "máquina" to 15.000,
            "navaja" to 18.000,
            "arreglo de barba" to 5.000,
        )

        // Configuración del RecyclerView
        binding.rvProducts.layoutManager = LinearLayoutManager(this)
        binding.rvProducts.adapter = ProductAdapter(products)

        val discountMessage = "Si te interesa alguno de estos productos, no dudes de pedírmelo cuando vengas y tendrás un 35% de descuento."
    }
}
