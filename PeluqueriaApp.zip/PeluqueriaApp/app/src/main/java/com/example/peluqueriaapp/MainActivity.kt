package com.example.peluqueriaapp.ui

import com.example.peluqueriaapp.ui.MainActivity
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.peluqueriaapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configuración del botón de Catálogo de Productos y Cortes
        binding.btnProductCatalog.setOnClickListener {
            // Navegar a la actividad del catálogo de productos
            val intent = Intent(this, ProductActivity::class.java)
            startActivity(intent)
        }

        // Configuración del botón de Agendar Cita
        binding.btnBooking.setOnClickListener {
            // Navegar a la actividad de agendar cita
            val intent = Intent(this, BookingActivity::class.java)
            startActivity(intent)
        }
    }
}
