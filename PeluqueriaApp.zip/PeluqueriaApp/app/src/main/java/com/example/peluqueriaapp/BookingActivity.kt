package com.example.peluqueriaapp.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.peluqueriaapp.databinding.ActivityBookingBinding
import java.util.*

class BookingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBookingBinding
    private val availableTimes = mutableListOf(
        "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00"
    )
    private var selectedTime: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBookingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupTimeSpinner()

        binding.btnConfirmBooking.setOnClickListener {
            if (selectedTime != null) {
                addEventToCalendar()
            } else {
                Toast.makeText(this, "Por favor, selecciona una hora disponible", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupTimeSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, availableTimes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerTime.adapter = adapter

        binding.spinnerTime.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                selectedTime = availableTimes[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                selectedTime = null
            }
        }
    }

    private fun addEventToCalendar() {
        val calendar = Calendar.getInstance()

        // Obtener la fecha seleccionada del DatePicker
        val year = binding.datePicker.year
        val month = binding.datePicker.month
        val day = binding.datePicker.dayOfMonth

        // Establecer la fecha y hora del evento
        val date = Calendar.getInstance()
        date.set(year, month, day)

        // Asumiendo que la hora seleccionada tiene el formato "HH:mm"
        val timeParts = selectedTime?.split(":")
        if (timeParts != null && timeParts.size == 2) {
            val hour = timeParts[0].toInt()
            val minute = timeParts[1].toInt()
            date.set(Calendar.HOUR_OF_DAY, hour)
            date.set(Calendar.MINUTE, minute)
        }

        // Crear un Intent para agregar el evento al calendario
        val intent = Intent(Intent.ACTION_INSERT).apply {
            data = android.provider.CalendarContract.Events.CONTENT_URI
            putExtra(android.provider.CalendarContract.Events.TITLE, "Cita de Peluquería")
            putExtra(android.provider.CalendarContract.Events.DESCRIPTION, "Cita reservada en la peluquería")
            putExtra(android.provider.CalendarContract.Events.EVENT_LOCATION, "Peluquería")
            putExtra(android.provider.CalendarContract.EXTRA_EVENT_BEGIN_TIME, date.timeInMillis)
            putExtra(android.provider.CalendarContract.EXTRA_EVENT_END_TIME, date.timeInMillis + 60 * 60 * 1000) // Duración de 1 hora
        }

        // Iniciar la actividad para que el usuario agregue el evento al calendario
        startActivity(intent)
    }
}
